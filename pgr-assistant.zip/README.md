<!--

 * @Author: 梦月時謌
 * @Date: 2022-12-15 22:51:45
 * @LastEditTime: 
-->

# 战双帕弥什助手

战双帕弥什助手

### 开发工具
以下均为手机端开发工具

Auto.js pro 付费，
https://pro.autojs.org/

Auto.js 免费，bug多，开发者已不再维护
https://hyb1996.github.io/AutoJs-Docs/#/
 
Autox.js 免费，第三方维护的auto.js免费版
http://doc.autoxjs.com/

